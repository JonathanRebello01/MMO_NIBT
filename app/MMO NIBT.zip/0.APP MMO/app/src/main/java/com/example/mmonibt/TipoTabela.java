package com.example.mmonibt;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class TipoTabela extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tipo_tabela);
        getSupportActionBar().hide();
    }
}